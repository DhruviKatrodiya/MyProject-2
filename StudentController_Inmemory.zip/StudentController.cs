﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using MVCFirstDemoAppCS.Models;

namespace MVCFirstDemoAppCS.Controllers
{
    public class StudentController : Controller
    {
        private static List<Student> students = new List<Student>();
        public StudentController()
        {
            if(students.Count == 0)
            { 
            students.Add(new Student { StudentId = 1 , StudentName = "Dhruvi" , City = "Surat" , StudentAge = 21 , TotalMarks = 600});
            students.Add(new Student { StudentId = 2, StudentName = "Shilpa", City = "Vadodara", StudentAge = 20, TotalMarks = 500 });
            students.Add(new Student { StudentId = 3, StudentName = "Daya", City = "Bharuch", StudentAge = 25, TotalMarks = 450 });
            }
        }
        // GET: Student
        public ActionResult Index()
        {
            return View(students.ToList());
        }

        // GET: Student/Details/5
        public ActionResult Details(int id)
        {
            return View(GetStudentById(id));
        }

        // GET: Student/Create
        public ActionResult Create()
        {
            return View();
        }

        // POST: Student/Create
        [HttpPost]
        public ActionResult Create(Student student )
        {
            try
            {
                // TODO: Add insert logic here
                //int studId = (from stud in students
                  //            select stud.StudentId).Max() + 1;

                student.StudentId = students.Max(s => s.StudentId) + 1;
                
                students.Add(student);

                return RedirectToAction("Index");
            }
            catch
            {
                return View();
            }
        }

        // GET: Student/Edit/5
        public ActionResult Edit(int id)
        {
            return View(GetStudentById(id));
        }

        // POST: Student/Edit/5
        [HttpPost]
        public ActionResult Edit(int id, Student student)
        {
            try
            {
                // TODO: Add update logic here
                Student studentToEdit = GetStudentById(id);
                studentToEdit.StudentName = student.StudentName;
                studentToEdit.City = student.City;
                studentToEdit.StudentAge = student.StudentAge;
                studentToEdit.TotalMarks = student.TotalMarks;
                return RedirectToAction("Index");
            }
            catch
            {
                return View();
            }
        }

        // GET: Student/Delete/5
        public ActionResult Delete(int id)
        {
            //Student studentToDelete = GetStudentById(id);
            return View(GetStudentById(id));
        }

        // POST: Student/Delete/5
        [HttpPost]
        public ActionResult Delete(int id, FormCollection collection)
        {
            try
            {
                // TODO: Add delete logic here

                Student studentToDelete = GetStudentById(id);
                if (studentToDelete != null)
                    students.Remove(studentToDelete);

                return RedirectToAction("Index");
            }
            catch
            {
                return View();
            }
        }

        private Student GetStudentById(int id)
        {
            Student studentToDelete = students.SingleOrDefault(s => s.StudentId == id);
            return studentToDelete;
        }
    }
}
